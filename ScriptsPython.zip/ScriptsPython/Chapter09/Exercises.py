# Exercise 1:


# Exercise 9.2:
def linear_search(data, target):
  for element in data:
    if element == target:
      return True
  return False
 
# Example of usage 
arr = [3, 4, 2, 1, 5]
x = 1
print(linear_search(arr, x))  # Output: True

def binary_search(data, target, low, high):
  if low > high:
    return False
  mid = (low + high) // 2
  if data[mid] == target:
    return mid
  elif target < data[mid]:
    return binary_search(data, target, low, mid - 1)
  else:
    return binary_search(data, target, mid + 1, high)

# Example of usage 
arr = [1, 2, 3, 4, 5]
x = 4
print(binary_search(arr, x, 0, len(arr) - 1))  # Output: 3
# Exercise 9.3:
def bubble_sort(data):
  """
  Sorts a list of numbers in ascending order using bubble sort.  
  Args:
      data: The unsorted list of numbers.
  Returns:
      A new list containing the sorted numbers.
  """
  n = len(data)
  swapped = True
  while swapped:
    swapped = False
    for i in range(n - 1):
      if data[i] > data[i + 1]:
        data[i], data[i + 1] = data[i + 1], data[i]  # Swap elements
        swapped = True
  return data

# Usage Example
unsorted_list = [64, 34, 25, -5, 12, 22, 3.14, 11, 90]
sorted_list = bubble_sort(unsorted_list.copy())  # Avoid modifying the original list
print("Sorted array is:", sorted_list)
# Output: Sorted array is: [-5, 3.14, 11, 12, 22, 25, 34, 64, 90]

def selection_sort(data):
  """
  Sorts a list of numbers in ascending order using selection sort.
  Args:
      data: The unsorted list of numbers.
  Returns:
      A new list containing the sorted numbers.
  """
  n = len(data)
  for i in range(n):
    min_index = i  # Initialize the minimum index to the current position
    for j in range(i + 1, n):  # Iterate through the remaining elements
      if data[j] < data[min_index]:  # Find the minimum element in the unsorted part
        min_index = j
    # Swap the minimum element with the first element of the unsorted part
    data[i], data[min_index] = data[min_index], data[i]

  return data

# Example usage
unsorted_list = [8, 4, 2,17, 1, 5,-5.75, 3.14, 9, 3, 6, 7]
sorted_list = selection_sort(unsorted_list.copy()) 
print("Sorted list is:", sorted_list)
#Output: Sorted array is: [-5.75, 1, 2, 3, 3.14, 4, 5, 6, 7, 8, 9, 17]



# Exercise 4:


# Exercise 5:
def merge_sorted_lists(list1, list2):
    merged = []
    i, j = 0, 0

    # Traverse both lists and insert smaller value in merged
    while i < len(list1) and j < len(list2):
        if list1[i] < list2[j]:
            merged.append(list1[i])
            i += 1
        else:
            merged.append(list2[j])
            j += 1

    # If list1 still has elements, add them
    while i < len(list1):
        merged.append(list1[i])
        i += 1

    # If list2 still has elements, add them
    while j < len(list2):
        merged.append(list2[j])
        j += 1

    return merged

# Usage Example
list1 = [0, 30, 50, 70]
list2 = [20, 40, 60, 80]
merged_list = merge_sorted_lists(list1, list2)
print("Merged sorted list:", merged_list)
# Expected Output: Merged sorted list: [1, 2, 3, 4, 5, 6, 7, 8]


def optimized_bubble_sort(lst):
    n = len(lst)  # Get the number of items in the list
    for i in range(n):
        swapped = False  # This flag will check if a swap has occurred
        for j in range(0, n-i-1):
            # Compare adjacent items
            if lst[j] > lst[j+1]:
                # Swap them if they're in the wrong order
                lst[j], lst[j+1] = lst[j+1], lst[j]
                swapped = True  # Mark that a swap occurred
        if not swapped:
            # If no swaps occurred, the list is sorted
            break
    return lst   
lst = [5, 10, 4, -2, 8, 0]
sorted_lst = optimized_bubble_sort(lst)
print("Sorted list:", sorted_lst)
# Expected Output: Sorted list: [-2, 0, 4, 5, 8, 10]

def two_sum(nums, target):
    seen = {}  # Initialize an empty dictionary to store numbers and their indices
    for i, num in enumerate(nums):  # Loop through the list, with both index and value
        complement = target - num  # Calculate the complement of the current number
        if complement in seen:  # Check if the complement is already in the dictionary
            # If found, return the indices of the complement and the current number
            return [seen[complement], i]
        seen[num] = i  # Store the current number and its index in the dictionary
    return None  # If no two numbers sum up to the target, return None
# Usage example
nums = [2, 5, 11, 15, 7]
target = 9
result = two_sum(nums, target)
print("Indices of the two numbers that sum to the target:", result)
# Expected Output: Indices of the two numbers that sum to the target: [0, 4]

def factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n - 1)
       

for i in range(6):
	print(f"{i} ! = {factorial(i)}")


# Exercise 6:


# Exercise 7:


# Exercise 8:


# Exercise 9:


# Exercise 10:


# Exercise 11:


# Exercise 12:


# Exercise 13:


# Exercise 14:


# Exercise 15:
