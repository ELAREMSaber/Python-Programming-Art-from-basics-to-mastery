# Exercise 10.1:
## 1
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

print(fibonacci(5))

## 2
def is_palindrome(s):
    if len(s) <= 1:
        return True
    if s[0] != s[-1]:
        return False
    return is_palindrome(s[1:-1])

print(is_palindrome("racecar"))

## 3

def gcd(a, b):
    if b == 0:
        return a
    return gcd(b, a % b)

print(gcd(56, 98))

## 4

def factorial(n):
    if n == 0:
        return 1
    return n * factorial(n-1)

print(factorial(5))

# Exercise 10.2:

## 1
def merge_sort(arr):
    if len(arr) <= 1:
        return arr
    
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])
    
    return merge(left, right)

def merge(left, right):
    result = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] < right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1

    result.extend(left[i:])
    result.extend(right[j:])
    return result

print(merge_sort([38, 27, 43, 3, 9, 82, 10]) )
## 2

def find_peak(arr):
    return peak_util(arr, 0, len(arr)-1)

def peak_util(arr, low, high):
    mid = (high + low) // 2
    
    if (mid == 0 or arr[mid-1] <= arr[mid]) and \
       (mid == len(arr)-1 or arr[mid+1] <= arr[mid]):
        return mid
    if mid > 0 and arr[mid-1] > arr[mid]:
        return peak_util(arr, low, mid-1)
    return peak_util(arr, mid+1, high)

# For example, given the array [5, 10, 20, 15], 
# find_peak returns the index 2 (since 20 is the peak element).
print(find_peak([5,10, 20, 15]))
## 3

def majority_element(nums):
    return majority_element_rec(nums, 0, len(nums)-1)

def majority_element_rec(nums, lo, hi):
    if lo == hi:
        return nums[lo]

    mid = (hi-lo)//2 + lo
    left = majority_element_rec(nums, lo, mid)
    right = majority_element_rec(nums, mid+1, hi)

    if left == right:
        return left
    
    left_count = sum(1 for i in range(lo, hi+1) if nums[i] == left)
    right_count = sum(1 for i in range(lo, hi+1) if nums[i] == right)

    return left if left_count > right_count else right

print(majority_element([3, 3, 4, 2, 4, 4, 2, 4, 4]))


# Exercise 3:
## 1
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right

def is_valid_BST(root, left=None, right=None):
    if not root:
        return True
    if left and root.val <= left.val:
        return False
    if right and root.val >= right.val:
        return False
    return is_valid_BST(root.left, left, root) and is_valid_BST(root.right, root, right)

# Test cases
empty_tree = None
single_node = TreeNode(1)
valid_bst = TreeNode(2, TreeNode(1), TreeNode(3))
invalid_bst_right = TreeNode(5, TreeNode(1), TreeNode(4, TreeNode(3), TreeNode(6)))
invalid_bst_left = TreeNode(10, TreeNode(5, TreeNode(1), TreeNode(12)), TreeNode(15))

tests = [
    (empty_tree, True),
    (single_node, True),
    (valid_bst, True),
    (invalid_bst_right, False),
    (invalid_bst_left, False)
]

for index, (tree, expected) in enumerate(tests, 1):
    result = is_valid_BST(tree)
    print(f"Test Case {index}: {'Passed' if result == expected else 'Failed'}")

## 2

from collections import deque

def shortest_path_BFS(graph, start, end):
    if start == end:
        return [start]
    
    visited = set()
    queue = deque([(start, [start])])
    
    while queue:
        (vertex, path) = queue.popleft()
        if vertex not in visited:
            visited.add(vertex)
            if vertex in graph:
                for neighbor in graph[vertex]:
                    if neighbor == end:
                        return path + [neighbor]
                    queue.append((neighbor, path + [neighbor]))
                
    return None

# Test cases setup
graphs = {
    "simple_path": ({'A': ['B'], 'B': ['C'], 'C': ['D'], 'D': []}, 'A', 'D'),
    "with_branches": ({'A': ['B', 'C'], 'B': ['D'], 'C': ['D'], 'D': ['E'], 'E': []}, 'A', 'E'),
    "disconnected": ({'A': ['B'], 'B': [], 'C': ['D'], 'D': []}, 'A', 'D'),
    "cycle": ({'A': ['B', 'C'], 'B': ['A', 'D'], 'C': ['A', 'D'], 'D': ['E'], 'E': ['B']}, 'A', 'E'),
    "single_node": ({'A': ['B', 'C'], 'B': ['C'], 'C': ['D'], 'D': []}, 'A', 'A')
}

# Execute and print test case results
for name, (graph, start, end) in graphs.items():
    result = shortest_path_BFS(graph, start, end)
    print(f"Test {name.replace('_', ' ').title()}: {result}")

## 3

def has_cycle(graph):
    visited = set()
    stack = []

    for vertex in graph:
        if vertex not in visited:
            if dfs_cycle(graph, vertex, visited, stack):
                return True
    return False

def dfs_cycle(graph, vertex, visited, stack):
    visited.add(vertex)
    stack.append(vertex)

    for neighbor in graph[vertex]:
        if neighbor not in visited:
            if dfs_cycle(graph, neighbor, visited, stack):
                return True
        elif neighbor in stack:
            return True

    stack.pop()
    return False

# Test cases
graphs = {
    "no_cycle": {'A': ['B'], 'B': ['C'], 'C': []},
    "simple_cycle": {'A': ['B'], 'B': ['A']},
    "complex_cycle": {'A': ['B'], 'B': ['C', 'D'], 'C': ['E'], 'D': [], 'E': ['B']},
    "disjoint_graph_with_cycle": {'A': ['B'], 'B': ['C'], 'C': ['A'], 'D': ['E'], 'E': []},
    "graph_with_self_loop": {'A': ['A'], 'B': []},
    "empty_graph": {}
}

for name, graph in graphs.items():
    result = has_cycle(graph)
    print(f"Test {name.replace('_', ' ').title()}: {result}")

## 4

def lowest_common_ancestor(root, p, q):
    if not root:
        return None
    
    if root.val > p.val and root.val > q.val:
        return lowest_common_ancestor(root.left, p, q)
    elif root.val < p.val and root.val < q.val:
        return lowest_common_ancestor(root.right, p, q)
    else:
        return root

# Given nodes p and q in the BST, the function returns their lowest common ancestor.

# Exercise 4:


# Exercise 5:


# Exercise 6:


# Exercise 7:


# Exercise 8:


# Exercise 9:


# Exercise 10:


# Exercise 11:


# Exercise 12:


# Exercise 13:


# Exercise 14:


# Exercise 15:
