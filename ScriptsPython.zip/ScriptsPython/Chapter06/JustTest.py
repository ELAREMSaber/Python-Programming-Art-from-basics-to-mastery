import shutil
import os

def backup_directory(src_directory, dest_directory="backup"):
    if not os.path.exists(dest_directory):
        os.makedirs(dest_directory)
    for item in os.listdir(src_directory):
        src_item = os.path.join(src_directory, item)
        dest_item = os.path.join(dest_directory, item)
        if os.path.isdir(src_item):
            shutil.copytree(src_item, dest_item)
        else:
            shutil.copy2(src_item, dest_item)

backup_directory("source_directory")

