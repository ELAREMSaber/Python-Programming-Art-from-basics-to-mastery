# Exercise 1: 
with open("data.txt", "r") as file:
    content = file.read()
    print(content)

# Exercise 2: 
with open("data.txt", "r") as file:
    content = file.read()
    words = content.split()# Split the Content into Words
    print(f"Number of words: {len(words)}")

# Exercise 3: 
name = input("Enter your name: ")
age = input("Enter your age: ")

with open("user_details.txt", "w") as file:
    file.write(f"Name: {name}\nAge: {age}\n")

# Exercise 4: 
hobbies = input("Enter at least three hobbies, separated by commas: ").split(",")

with open("user_details.txt", "a") as file:
    file.write("\nHobbies:\n")
    for hobby in hobbies:
        file.write(f"- {hobby.strip()}\n")

# Exercise 5: 
with open("example.txt", "w+") as file:
    file.write("This is some sample text.")
    file.seek(0)  # Reset the file position to the beginning
    print(file.read())

# Exercise 6: 
import os

txt_files = [f for f in os.listdir() if f.endswith('.txt')]
print(txt_files)

# Exercise 7: 
import os
import shutil

# Create directory if it doesn't exist
if not os.path.exists('data_files'):
    os.makedirs('data_files')

# Move the file
shutil.move('data.txt', 'data_files/data.txt')

# Exercise 8: 
import os
if not os.path.isfile('notes.txt'):
    with open('notes.txt', 'w') as file:
        pass  # Simply create the file without writing anything

# Exercise 9: 
# Define the file path
file_path = 'data.txt'

# Read the content of the file
with open(file_path, 'r') as file:
    lines = file.readlines()

# Process the header
header = lines[0].strip() + ',Product\n'
processed_lines = [header]

# Process each line (excluding the header)
for line in lines[1:]:
    # Split the line into numbers, strip removes newline characters
    number1, number2 = line.strip().split(',')
    # Calculate the product of the two numbers
    product = int(number1) * int(number2)
    # Append the product to the line
    processed_line = f"{number1},{number2},{product}\n"
    processed_lines.append(processed_line)

# Write the updated content back to the file
with open(file_path, 'w') as file:
    file.writelines(processed_lines)

print("The file has been updated with the products of the numbers.")

# Exercise 10: 
try:
    with open("non_existent_file.txt", "r") as file:
        content = file.read()
except FileNotFoundError:
    print("The file you are trying to read does not exist.")

# Exercise 11: 
try:
    with open("example.txt", "r") as file:
        file.write("Trying to write to a read-only file.")
except IOError:
    print("An error occurred while trying to write to the file.")

# Exercise 12: 
num1 = float(input("Enter the numerator: "))
num2 = float(input("Enter the denominator: "))

try:
    result = num1 / num2
    print(f"The result is: {result}")
except ZeroDivisionError:
    print("You cannot divide by zero.")

# Exercise 13: 
try:
    with open("example.txt", "r") as file:
        lines = file.readlines()
except FileNotFoundError:
    print("The file does not exist.")
else:
    print(f"The file has {len(lines)} lines.")

# Exercise 14: 
class InvalidOperationError(Exception):
    pass

operation = input("Enter an operation (add/sub/mul/div): ")

if operation not in ["add", "sub", "mul", "div"]:
    raise InvalidOperationError("The operation entered is not valid.")

# Exercise 15: 
try:
    with open("/", "r") as file:  # This tries to open root directory as a file
        content = file.read()
except IsADirectoryError:
    print("The path you are trying to open is a directory, not a file.")

# Exercise 16: 
import os

try:
    os.remove("non_existent_file.txt")
except FileNotFoundError:
    print("The file you are trying to delete does not exist.")

# Exercise 17: 
import os

# Create the file and write some content
with open("readonly.txt", "w") as file:
    file.write("This is a read-only file.")

# Modify the file's permissions to be read-only
os.chmod("readonly.txt", 0o444)  # octal notation for read-only permissions

# Try writing to the file
try:
    with open("readonly.txt", "w") as file:
        file.write("Trying to write to a read-only file.")
except PermissionError:
    print("You do not have permission to write to this file.")

# Exercise 18: 
import datetime

def log_message(message, log_file="log.txt"):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(log_file, "a") as file:
        file.write(f"{timestamp} - {message}\n")

log_message("This is a log message.")

# Exercise 19: 
import json

# First, create a default configuration file
config = {
    "resolution": "1920x1080",
    "volume": 75
}

with open("game_config.json", "w") as file:
    json.dump(config, file)

# Program to read and modify settings
def change_setting(setting_name, new_value, config_file="game_config.json"):
    with open(config_file, "r") as file:
        config = json.load(file)
        config[setting_name] = new_value
    with open(config_file, "w") as file:
        json.dump(config, file)

change_setting("volume", 80)


# Exercise 20: 
import shutil
import os

def backup_directory(src_directory, dest_directory="backup"):
    if not os.path.exists(dest_directory):
        os.makedirs(dest_directory)
    for item in os.listdir(src_directory):
        src_item = os.path.join(src_directory, item)
        dest_item = os.path.join(dest_directory, item)
        if os.path.isdir(src_item):
            shutil.copytree(src_item, dest_item)
        else:
            shutil.copy2(src_item, dest_item)

backup_directory("source_directory")

