import tkinter as tk
from tkinter import messagebox

class QuizApp:

    def __init__(self, root):
        self.root = root
        self.root.title("High School Quiz")
        
        # Sample questions
        self.questions = [
            {
                "question": "What is the capital of France?",
                "options": ["London", "Berlin", "Paris", "Madrid"],
                "answer": "Paris"
            },
            {
                "question": "Which gas do plants absorb from the atmosphere?",
                "options": ["Oxygen", "Carbon Dioxide", "Nitrogen", "Helium"],
                "answer": "Carbon Dioxide"
            }
        ]
        self.current_question = 0
        
        # Question Label
        self.question_label = tk.Label(root, text=self.questions[self.current_question]["question"])
        self.question_label.pack(pady=20)
        
        # Radiobuttons for Options
        self.option_var = tk.StringVar()
        self.option_var.set(None)
        
        self.options_frame = tk.Frame(root)
        self.options_frame.pack(pady=20)
        
        for option in self.questions[self.current_question]["options"]:
            tk.Radiobutton(self.options_frame, text=option, variable=self.option_var, value=option).pack(anchor='w', padx=10)
        
        # Buttons
        tk.Button(root, text="Submit", command=self.check_answer).pack(side="left", padx=20)
        tk.Button(root, text="Next", command=self.next_question).pack(side="right", padx=20)
        
        # Feedback Area
        self.feedback_label = tk.Label(root, text="")
        self.feedback_label.pack(pady=20)

    def check_answer(self):
        user_answer = self.option_var.get()
        correct_answer = self.questions[self.current_question]["answer"]
        
        if user_answer == correct_answer:
            self.feedback_label.config(text="Correct!", fg="green")
        else:
            self.feedback_label.config(text=f"Incorrect! The correct answer was {correct_answer}.", fg="red")

    def next_question(self):
        self.current_question += 1
        if self.current_question < len(self.questions):
            self.question_label.config(text=self.questions[self.current_question]["question"])
            self.option_var.set(None)
            for widget in self.options_frame.winfo_children():
                widget.destroy()
            for option in self.questions[self.current_question]["options"]:
                tk.Radiobutton(self.options_frame, text=option, variable=self.option_var, value=option).pack(anchor='w', padx=10)
            self.feedback_label.config(text="")
        else:
            self.feedback_label.config(text="Quiz Completed!", fg="blue")
            self.root.after(2000, self.root.quit)

root = tk.Tk()
app = QuizApp(root)
root.mainloop()
