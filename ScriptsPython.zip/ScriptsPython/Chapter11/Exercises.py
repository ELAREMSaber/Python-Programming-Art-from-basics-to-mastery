# Exercise 1: 
import tkinter as tk
import tkinter as tk

def draw_line(canvas, x1, y1, x2, y2):
    """Draws a line on the given canvas from point (x1, y1) to (x2, y2)."""
    canvas.create_line(x1, y1, x2, y2)

root = tk.Tk()
root.title("Drawing with Lines")

canvas = tk.Canvas(root, bg="white", width=400, height=400)
canvas.pack(pady=20)

# Coordinates for a 5-pointed star
star_coords = [
    (200, 100), (250, 300), 
    (100, 150), (300, 150), 
    (150, 300), (200, 100)
]

# Draw the star using the draw_line function
for i in range(len(star_coords)):
    x1, y1 = star_coords[i]
    x2, y2 = star_coords[(i+1) % len(star_coords)]
    draw_line(canvas, x1, y1, x2, y2)

root.mainloop()
 
# Exercise 2: 
import tkinter as tk

def draw_line(canvas, x1, y1, x2, y2):
    """Draws a line on the given canvas from point (x1, y1) to (x2, y2)."""
    canvas.create_line(x1, y1, x2, y2)

def draw_rectangle(canvas, top_left, bottom_right):
    """Draws a rectangle using the draw_line function."""
    x1, y1 = top_left
    x2, y2 = bottom_right
    draw_line(canvas, x1, y1, x2, y1)  # Top line
    draw_line(canvas, x1, y1, x1, y2)  # Left line
    draw_line(canvas, x2, y1, x2, y2)  # Right line
    draw_line(canvas, x1, y2, x2, y2)  # Bottom line

def draw_triangle(canvas, v1, v2, v3):
    """Draws a triangle using the draw_line function."""
    draw_line(canvas, *v1, *v2)
    draw_line(canvas, *v2, *v3)
    draw_line(canvas, *v1, *v3)

def draw_motif(canvas, x, y):
    """Draws a custom motif at the given (x, y) location."""
    # Drawing a rectangle as the base
    draw_rectangle(canvas, (x, y), (x+100, y+60))
    # Drawing a triangle on top of the rectangle
    draw_triangle(canvas, (x, y), (x+50, y-40), (x+100, y))

root = tk.Tk()
root.title("Building Advanced Shapes from Lines")

canvas = tk.Canvas(root, bg="white", width=500, height=500)
canvas.pack(pady=20)

# Test the functions
draw_rectangle(canvas, (100, 100), (300, 250))
draw_triangle(canvas, (150, 100), (225, 20), (300, 100))
draw_motif(canvas, 350, 350)

root.mainloop() 
 
# Exercise 3: 
import tkinter as tk
from tkinter import ttk

def convert_units():
    value = float(entry_value.get())
    conversion_type = combo_type.get()
    unit = combo_unit.get()
    
    if conversion_type == "Length":
        if unit == "Meters":
            result = value * 39.37
            label_result.config(text=f"{value} Meters = {result:.2f} Inches")
        elif unit == "Kilometers":
            result = value * 0.621371
            label_result.config(text=f"{value} Kilometers = {result:.2f} Miles")
    elif conversion_type == "Weight":
        result = value * 2.20462
        label_result.config(text=f"{value} Kilograms = {result:.2f} Pounds")
    elif conversion_type == "Volume":
        result = value * 0.264172
        label_result.config(text=f"{value} Liters = {result:.2f} Gallons")
    elif conversion_type == "Temperature":
        result = (value * 9/5) + 32
        label_result.config(text=f"{value}° Celsius = {result:.2f}° Fahrenheit")

root = tk.Tk()
root.title("Unit Converter")

label_type = ttk.Label(root, text="Select Measurement Type:")
label_type.pack(pady=10)
combo_type = ttk.Combobox(root, values=["Length", "Weight", "Volume", "Temperature"])
combo_type.pack(pady=10)

label_unit = ttk.Label(root, text="Select Unit:")
label_unit.pack(pady=10)
combo_unit = ttk.Combobox(root)
combo_unit.pack(pady=10)

def update_units(event):
    conversion_type = combo_type.get()
    if conversion_type == "Length":
        combo_unit["values"] = ["Meters", "Kilometers"]
    elif conversion_type == "Weight":
        combo_unit["values"] = ["Kilograms"]
    elif conversion_type == "Volume":
        combo_unit["values"] = ["Liters"]
    elif conversion_type == "Temperature":
        combo_unit["values"] = ["Celsius"]

combo_type.bind("<<ComboboxSelected>>", update_units)

label_entry = ttk.Label(root, text="Enter Value:")
label_entry.pack(pady=10)
entry_value = ttk.Entry(root)
entry_value.pack(pady=10)

button_convert = ttk.Button(root, text="Convert", command=convert_units)
button_convert.pack(pady=20)

label_result = ttk.Label(root, text="Result will appear here.")
label_result.pack(pady=10)

root.mainloop() 
 
# Exercise 4: 
import tkinter as tk
from tkinter import simpledialog, messagebox, Listbox, Scrollbar
from datetime import datetime
import os

class DiaryApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Personal Diary Application")

        # Create Widgets
        self.diary_text = tk.Text(self.root, width=60, height=20)
        self.save_button = tk.Button(self.root, text="Save Entry", command=self.save_entry)
        self.entries_listbox = Listbox(self.root)
        self.scrollbar = Scrollbar(self.root, orient="vertical", command=self.entries_listbox.yview)

        # Grid placement
        self.diary_text.grid(row=0, column=0, padx=10, pady=10)
        self.save_button.grid(row=1, column=0, pady=10)
        self.entries_listbox.grid(row=0, column=1, padx=10)
        self.scrollbar.grid(row=0, column=2, sticky='ns')

        # Configurations
        self.entries_listbox.config(yscrollcommand=self.scrollbar.set)
        self.entries_listbox.bind('<<ListboxSelect>>', self.load_entry)
        
        # Initialize diary entries list
        self.load_entries()

    def save_entry(self):
        content = self.diary_text.get("1.0", "end-1c")  # Get content from the Text widget
        if content:
            timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
            with open(f"entry_{timestamp}.txt", 'w') as f:
                f.write(content)
            self.load_entries()
            self.diary_text.delete("1.0", "end")
            messagebox.showinfo("Info", "Diary entry saved successfully!")
        else:
            messagebox.showwarning("Warning", "Cannot save empty entry!")

    def load_entries(self):
        files = [f for f in os.listdir() if f.startswith("entry_")]
        self.entries_listbox.delete(0, "end")
        for file in sorted(files, reverse=True):
            entry_date = datetime.strptime(file, "entry_%Y%m%d%H%M%S.txt")
            formatted_date = entry_date.strftime("%B %d, %Y %H:%M:%S")
            self.entries_listbox.insert("end", formatted_date)

    def load_entry(self, event):
        selected_entry = self.entries_listbox.get(self.entries_listbox.curselection())
        timestamp = datetime.strptime(selected_entry, "%B %d, %Y %H:%M:%S").strftime("%Y%m%d%H%M%S")
        with open(f"entry_{timestamp}.txt", 'r') as f:
            content = f.read()
        self.diary_text.delete("1.0", "end")
        self.diary_text.insert("end", content)

if __name__ == "__main__":
    root = tk.Tk()
    app = DiaryApp(root)
    root.mainloop() 
 
# Exercise 5: 
import tkinter as tk
from tkinter import ttk  # themed tkinter for better-looking GUI

class CurrencyConverter:
    def __init__(self, root):
        self.root = root
        self.root.title("Currency Converter")

        # Exchange rates (as an example, you can update or fetch live rates)
        self.exchange_rates = {
            'USD': {'USD': 1, 'EUR': 0.85, 'GBP': 0.75, 'JPY': 110},
            'EUR': {'USD': 1.18, 'EUR': 1, 'GBP': 0.88, 'JPY': 130},
            'GBP': {'USD': 1.33, 'EUR': 1.14, 'GBP': 1, 'JPY': 148},
            'JPY': {'USD': 0.0091, 'EUR': 0.0077, 'GBP': 0.0067, 'JPY': 1}
        }

        # Create Widgets
        self.amount_label = ttk.Label(root, text="Amount:")
        self.amount_entry = ttk.Entry(root)
        self.from_currency_label = ttk.Label(root, text="From Currency:")
        self.from_currency = ttk.Combobox(root, values=list(self.exchange_rates.keys()))
        self.to_currency_label = ttk.Label(root, text="To Currency:")
        self.to_currency = ttk.Combobox(root, values=list(self.exchange_rates.keys()))
        self.convert_button = ttk.Button(root, text="Convert", command=self.convert)
        self.result_var = tk.StringVar()
        self.result_label = ttk.Label(root, textvariable=self.result_var)

        # Default values
        self.from_currency.set('USD')
        self.to_currency.set('EUR')

        # Grid placement
        self.amount_label.grid(row=0, column=0, padx=10, pady=10)
        self.amount_entry.grid(row=0, column=1, padx=10, pady=10)
        self.from_currency_label.grid(row=1, column=0, padx=10)
        self.from_currency.grid(row=1, column=1, padx=10)
        self.to_currency_label.grid(row=2, column=0, padx=10)
        self.to_currency.grid(row=2, column=1, padx=10)
        self.convert_button.grid(row=3, column=0, columnspan=2, pady=10)
        self.result_label.grid(row=4, column=0, columnspan=2, pady=10)

    def convert(self):
        try:
            amount = float(self.amount_entry.get())
            from_cur = self.from_currency.get()
            to_cur = self.to_currency.get()
            conversion_rate = self.exchange_rates[from_cur][to_cur]
            converted_amount = round(amount * conversion_rate, 2)
            self.result_var.set(f"{amount} {from_cur} = {converted_amount} {to_cur}")
        except ValueError:
            self.result_var.set("Invalid input. Please enter a valid number.")

if __name__ == "__main__":
    root = tk.Tk()
    app = CurrencyConverter(root)
    root.mainloop() 
 
# Exercise 6: 
import tkinter as tk
from tkinter import messagebox, ttk

class TodoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("To-Do List App")

        # Widgets
        self.task_entry = ttk.Entry(root, width=40)
        self.add_button = ttk.Button(root, text="Add Task", command=self.add_task)
        self.complete_button = ttk.Button(root, text="Mark as Complete", command=self.mark_complete)
        self.remove_button = ttk.Button(root, text="Remove Task", command=self.remove_task)
        self.clear_button = ttk.Button(root, text="Clear All", command=self.clear_all)

        self.tasks_listbox = tk.Listbox(root, width=50, height=15)

        # Grid placements
        self.task_entry.grid(row=0, column=0, padx=10, pady=10)
        self.add_button.grid(row=0, column=1, padx=10, pady=10)
        self.complete_button.grid(row=1, column=1, padx=10)
        self.remove_button.grid(row=2, column=1, padx=10)
        self.clear_button.grid(row=3, column=1, padx=10, pady=10)
        self.tasks_listbox.grid(row=1, column=0, rowspan=4, padx=10, pady=10)

    def add_task(self):
        task = self.task_entry.get()
        if task:
            self.tasks_listbox.insert(tk.END, task)
            self.task_entry.delete(0, tk.END)
        else:
            messagebox.showwarning("Warning", "Please enter a task!")

    def mark_complete(self):
        try:
            index = self.tasks_listbox.curselection()
            self.tasks_listbox.itemconfig(index, {"bg":"light green"})
        except:
            messagebox.showwarning("Warning", "Please select a task to mark as complete!")

    def remove_task(self):
        try:
            index = self.tasks_listbox.curselection()
            self.tasks_listbox.delete(index)
        except:
            messagebox.showwarning("Warning", "Please select a task to remove!")

    def clear_all(self):
        self.tasks_listbox.delete(0, tk.END)

if __name__ == "__main__":
    root = tk.Tk()
    app = TodoApp(root)
    root.mainloop() 
 
# Exercise 7: 
import tkinter as tk
from tkinter import ttk, simpledialog, messagebox

class TaskManager:

    def __init__(self, root):
        self.root = root
        self.root.title("High School Task Manager")

        # Create input fields
        tk.Label(root, text="Task Name:").grid(row=0, column=0)
        self.task_name_var = tk.StringVar()
        tk.Entry(root, textvariable=self.task_name_var).grid(row=0, column=1)

        tk.Label(root, text="Due Date (DD/MM/YYYY):").grid(row=1, column=0)
        self.due_date_var = tk.StringVar()
        tk.Entry(root, textvariable=self.due_date_var).grid(row=1, column=1)

        tk.Label(root, text="Subject:").grid(row=2, column=0)
        subjects = ["Math", "Science", "History", "Language", "Physical Education"]
        self.subject_var = tk.StringVar()
        ttk.Combobox(root, values=subjects, textvariable=self.subject_var).grid(row=2, column=1)

        tk.Label(root, text="Description:").grid(row=3, column=0)
        self.desc_var = tk.StringVar()
        tk.Entry(root, textvariable=self.desc_var).grid(row=3, column=1)

        # Create buttons
        tk.Button(root, text="Add Task", command=self.add_task).grid(row=4, column=0)
        tk.Button(root, text="Remove Task", command=self.remove_task).grid(row=4, column=1)

        # Create Listbox
        self.tasks_listbox = ttk.Treeview(root, columns=("Due Date", "Subject"))
        self.tasks_listbox.heading("#1", text="Due Date")
        self.tasks_listbox.heading("#2", text="Subject")
        self.tasks_listbox.grid(row=5, column=0, columnspan=2)

    def add_task(self):
        task_name = self.task_name_var.get()
        due_date = self.due_date_var.get()
        subject = self.subject_var.get()
        desc = self.desc_var.get()

        if task_name and due_date and subject:
            self.tasks_listbox.insert("", "end", text=task_name, values=(due_date, subject))
        else:
            messagebox.showerror("Error", "Please fill all fields before adding a task!")

    def remove_task(self):
        try:
            selected_item = self.tasks_listbox.selection()[0]
            self.tasks_listbox.delete(selected_item)
        except:
            messagebox.showwarning("Warning", "Please select a task to remove!")

root = tk.Tk()
app = TaskManager(root)
root.mainloop()
 
# Exercise 8: 
import tkinter as tk
from tkinter import messagebox

class QuizApp:

    def __init__(self, root):
        self.root = root
        self.root.title("High School Quiz")
        
        # Sample questions
        self.questions = [
            {
                "question": "What is the capital of France?",
                "options": ["London", "Berlin", "Paris", "Madrid"],
                "answer": "Paris"
            },
            {
                "question": "Which gas do plants absorb from the atmosphere?",
                "options": ["Oxygen", "Carbon Dioxide", "Nitrogen", "Helium"],
                "answer": "Carbon Dioxide"
            }
        ]
        self.current_question = 0
        
        # Question Label
        self.question_label = tk.Label(root, text=self.questions[self.current_question]["question"])
        self.question_label.pack(pady=20)
        
        # Radiobuttons for Options
        self.option_var = tk.StringVar()
        self.option_var.set(None)
        
        self.options_frame = tk.Frame(root)
        self.options_frame.pack(pady=20)
        
        for option in self.questions[self.current_question]["options"]:
            tk.Radiobutton(self.options_frame, text=option, variable=self.option_var, value=option).pack(anchor='w', padx=10)
        
        # Buttons
        tk.Button(root, text="Submit", command=self.check_answer).pack(side="left", padx=20)
        tk.Button(root, text="Next", command=self.next_question).pack(side="right", padx=20)
        
        # Feedback Area
        self.feedback_label = tk.Label(root, text="")
        self.feedback_label.pack(pady=20)

    def check_answer(self):
        user_answer = self.option_var.get()
        correct_answer = self.questions[self.current_question]["answer"]
        
        if user_answer == correct_answer:
            self.feedback_label.config(text="Correct!", fg="green")
        else:
            self.feedback_label.config(text=f"Incorrect! The correct answer was {correct_answer}.", fg="red")

    def next_question(self):
        self.current_question += 1
        if self.current_question < len(self.questions):
            self.question_label.config(text=self.questions[self.current_question]["question"])
            self.option_var.set(None)
            for widget in self.options_frame.winfo_children():
                widget.destroy()
            for option in self.questions[self.current_question]["options"]:
                tk.Radiobutton(self.options_frame, text=option, variable=self.option_var, value=option).pack(anchor='w', padx=10)
            self.feedback_label.config(text="")
        else:
            self.feedback_label.config(text="Quiz Completed!", fg="blue")
            self.root.after(2000, self.root.quit)

root = tk.Tk()
app = QuizApp(root)
root.mainloop() 
 
# Exercise 9: 
import tkinter as tk
from tkinter import simpledialog, Listbox, messagebox

class EventCalendar:

    def __init__(self, root):
        self.root = root
        self.root.title("School Event Calendar")
        
        # Event Storage
        self.events = {}
        
        # Date Picker
        self.date_var = tk.StringVar()
        self.date_entry = tk.Entry(root, textvariable=self.date_var)
        self.date_entry.pack(pady=20)
        self.date_var.set("DD-MM-YYYY")
        
        # Event Display
        self.event_listbox = Listbox(root)
        self.event_listbox.pack(pady=20)
        
        # Buttons
        tk.Button(root, text="Add Event", command=self.add_event).pack(side="left", padx=10)
        tk.Button(root, text="Delete Event", command=self.delete_event).pack(side="left", padx=10)
        tk.Button(root, text="Show Events", command=self.show_events).pack(side="right", padx=10)
        
        # Status Bar
        self.status = tk.StringVar()
        self.status.set("Welcome to School Event Calendar!")
        self.status_bar = tk.Label(root, textvariable=self.status, bd=1, relief="sunken", anchor="w")
        self.status_bar.pack(side="bottom", fill="x")

    def add_event(self):
        date = self.date_var.get()
        event = simpledialog.askstring("Add Event", "Enter the event:")
        if event:
            if date in self.events:
                self.events[date].append(event)
            else:
                self.events[date] = [event]
            self.status.set(f"Event added for {date}")
        
    def delete_event(self):
        date = self.date_var.get()
        if date in self.events:
            selected_event = self.event_listbox.curselection()
            if selected_event:
                del self.events[date][selected_event[0]]
                self.status.set(f"Event deleted for {date}")
                self.show_events()
            else:
                self.status.set("Please select an event to delete.")
        else:
            self.status.set(f"No events found for {date}")

    def show_events(self):
        date = self.date_var.get()
        self.event_listbox.delete(0, tk.END)
        if date in self.events:
            for event in self.events[date]:
                self.event_listbox.insert(tk.END, event)
            self.status.set(f"Showing events for {date}")
        else:
            self.status.set(f"No events found for {date}")

root = tk.Tk()
app = EventCalendar(root)
root.mainloop() 
 
# Exercise 10: 
 
