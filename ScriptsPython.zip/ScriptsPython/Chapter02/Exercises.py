# Exercise  1: 
 #  Get input from the user
num1 = float(input("Enter the first number: "))
num2 = float(input("Enter the second number: "))
    
# Perform the division
result = num1 / num2
    
#  Display the result
print(f"{num1} divided by {num2} is {result}")


# Exercise  2: 
# Using list comprehension to get even numbers
even_numbers = [x for x in range(1, 21) if x % 2 == 0]
print(even_numbers) 


# Exercise  3: 

number_squares = {x: x**2 for x in range(1, 6)}
print(number_squares)


# Exercise  4:
 
# Step 1: Create a loop to iterate through numbers from 1 to 10
for number in range(1, 11):

    # Step 2: Check if the current number is 5
    if number == 5:
        # Step 3: Skip the current iteration
        continue
    
    # Step 4: Print the number
    print(number)


# Exercise  5: 
even_numbers_set = {x for x in range(2, 11, 2)}
print(even_numbers_set)


# Exercise  6: 

while True:  # Step 1: Start an infinite loop
    user_input = input("Please enter an integer: ")  # Step 2: Prompt for input
    
    # Step 3: Check for valid integer
    if user_input.isdigit() or (user_input[0] == '-' and user_input[1:].isdigit()):
        print(f"You've entered a valid integer: {user_input}")
        break  # Step 4: Break out of loop if input is a valid integer
    else:
        print("That's not a valid integer. Please try again.")

# Exercise  7:
 
for i in range(5):
    print(5*'*')


# Exercise  8: 
numbers = [1, 3, 5, 7, 9, 11, 13, 15]

# Step 1: Iterate over the list of numbers
for num in numbers:
    # Step 2: Check if the number is negative
    if num < 0:
        print(f"Found a negative number: {num}")
        # Step 3: Break out of the loop
        break
# Step 4: Use the else clause to handle the no-break scenario
else:
    print("The loop concluded without encountering any negative numbers.") 


# Exercise  9: 
def factorial(n):
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result

# Test the function
number = int(input("Enter a number to find its factorial: "))
if number < 0:
    print("Please enter a non-negative integer.")
else:
    print(f"The factorial of {number} is {factorial(number)}.") 


# Exercise  10:
 
# Step 1: Define the range
for num in range(10, 0, -1): # Start at 10, stop before 0, decrement by 1
    # Step 2 & 3: Iterate and print
    print(num) 


# Exercise  11:
 
# Step 1: Define the list comprehension
numbers = [num for num in range(1, 21) if num % 3 != 0]

# Step 2: Print the list
print(numbers) 


# Exercise  12:
 
# Step 1: Initialize a list
numbers = [34, 12, 89, 5, 23, 74]

# Step 2: Find the smallest number
smallest = min(numbers)

# Step 3: Print the smallest number
print(f"The smallest number in the list is: {smallest}")


# Exercise  13: 

 height = 5

# Step 1: Loop through numbers from 1 to height
for i in range(1, height + 1):
    
    # Step 2: Print spaces for alignment
    for j in range(height - i):
        print(" ", end="")
    
    # Step 3: Print asterisks to create the pyramid pattern
    for j in range(2*i - 1):
        print("*", end="")
    
    print()  # Move to the next line after each row

    


# Exercise  14:
 
original_dict = {'a': 1, 'b': 2, 'c': 3}

# Step 1 & 2: Iterate over pairs and swap them
inverted_dict = {value: key for key, value in original_dict.items()}
print(inverted_dict) 


# Exercise  15: 
numbers = [1, 2, 3, 4, 5]

# Step 1: Initialize a variable for the sum
sum_of_numbers = 0

# Step 2 & 3: Loop over each number and add to the cumulative sum
for number in numbers:
    sum_of_numbers += number

# Step 4: Calculate the average
average = sum_of_numbers / len(numbers)

# Print the results
print("Sum:", sum_of_numbers)
print("Average:", average)


# Exercise  16:
 
# Outer loop iterating over the first factor
for i in range(1, 10):  # Starts from 1, ends at 9
    # Inner loop iterating over the second factor
    for j in range(1, 10):  # Starts from 1, ends at 9
        # Calculate the product of i and j
        product = i * j
        # Print the formatted multiplication statement
        print(f"{i} X {j} = {product}") 


# Exercise  17:
 
# Step 1: Define a list of numbers
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Step 2: Iterate through the list
for num in numbers:
    # Step 3: Check if the current number is greater than 5
    if num > 5:
        # Step 4: Break out of the loop
        break
    print(num) 


# Exercise  18: 
# Step 1: Initialize sum and counter
total = 0
count = 0
# Step 2: Create a loop to prompt user input
while True:
        # Prompt the user for input
        number = input("Enter a number (or 'done' to finish): ")
        # Step 3: Check if the user wants to end the input
        if number.lower() == "done":
            break
        # Step 4: Convert to float, add to sum, increment counter
        total += float(number)
        count += 1
# Step 5: Compute the average
if count != 0:
    average = total / count
    # Step 6: Display the average
    print(f"Average of the entered numbers is: {average:.2f}")
else:
    print("No numbers were entered.") 


# Exercise  19: 
nums = [1, 2, 3, 4, 5]
print([x * 2 for x in nums if x % 2 == 0])



# Exercise  20: 
for i in range(2):
    for j in range(3):
        print(f"i={i}, j={j}") 


# Exercise  21: 
x = 10
while x > 5:
    print(x)
    x -= 1 


# Exercise  22: 
for i in range(1, 6):
    if i == 3:
        break
    print(i) 


# Exercise  23: 
numbers = [5, 3, 9, 1]
print(sorted(numbers)) 


# Exercise  24: 
x = 5
if x > 3:
    print("x is greater")
elif x < 3:
    print("x is smaller")
else:
    print("x is 3")

# Exercise  25:
age = 20
status = "Minor" if age < 18 else "Adult"
print(status)
# Exercise  26:

my_list = [2, 4, 6, 8]
for i in my_list:
    if i == 6:
        continue
    print(i)

# Exercise  27:  
# Ask the user to input a string
input_string = input("Please enter a string: ")

# Reversing the string and printing each character
# We use a slice that steps backwards through the string.
reversed_string = input_string[::-1]

# Print the reversed string
print("The reversed string is:", reversed_string)
