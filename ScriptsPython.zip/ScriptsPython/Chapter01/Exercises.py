  
# Exercise 2:
print("Hello, World!")
# Exercise 3:
name = "Nelson Mandela"
print(name)
# Exercise 4:
x = 5
y = 7
print("Sum:", x + y)
print("Difference:", x - y)
print("Product:", x * y)

 

# Exercise 6:

# Exercise 7:

# Exercise 8:

# Exercise 9:
name = "Louis Armstrong"
print(f"My name is {name} and I am learning Python.")
# Exercise 10:
a = 10
b = 20
a, b = b, a
# The result could be printed as:
print(f"a={a} and b ={b}")

# Exercise 11:
user_input = input("Enter something: ")
print(user_input)

# Exercise 12:


# Exercise 13:


# Exercise 14:


# Exercise 15:


# Exercise 16:
pi = 3.14159
print(round(pi, 3))

# Exercise 17:

# Exercise 18:
age = int(input("Enter your age: "))
if 13 <= age <= 19:
    print("You are a teenager.")
else:
    print("You are not a teenager.")
# Exercise 19:
multi_line_string = """
This is a multi-line string.
It spans multiple lines.
"""
print(multi_line_string)
# Exercise 20:


# Exercise 21:


# Step 1: Ask the user for their first name and store it in a variable.
first_name = input("Please enter your first name: ")
# Step 2: Ask the user for their last name and store it in a variable.
last_name = input("Please enter your last name: ")
# Step 3: Ask the user for their age and store it in a variable.
# We use int() to convert the age input from string to an integer.
age = int(input("Please enter your age: "))
# Step 4: Use an f-string to format and print the information.
# F-strings provide a way to embed expressions inside string literals, using curly braces {}.
print(f"Hello, {first_name} {last_name}. You are {age} years old.")


# Exercise 22:

# Python script to demonstrate various arithmetic operations
# Step 1: Ask the user to input two numbers, x and y.
x = float(input("Enter the first number (x): "))
y = float(input("Enter the second number (y): "))
# Check if the second number is zero to avoid division by zero errors.
if y == 0:
    print("Division by zero is not allowed. Please enter a non-zero number for y.")
else:
    # Step 2: Calculate and print the result of the division x/y.
    division = x / y
    print(f"{x} / {y} = {division}")
    # Step 3: Calculate and print the result of the integer division x//y.
    integer_division = x // y
    print(f"{x} // {y} = {integer_division}")
    # Step 4: Calculate and print the result of the modulo operation x%y.
    modulo = x % y
    print(f"{x} % {y} = {modulo}")
    # Step 5: Calculate and print the result of raising x to the power y (x**y).
    exponentiation = x ** y
    print(f"{x} ** {y} = {exponentiation}")
