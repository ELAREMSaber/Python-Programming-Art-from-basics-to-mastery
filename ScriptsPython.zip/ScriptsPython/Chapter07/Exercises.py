#Exercise 1:
import matplotlib.pyplot as plt
import numpy as np
# Define the range of x values
x = np.linspace(-10, 10, 100)  # Creating 100 points between -10 and 10
# Calculate y values using the function y = x^2
y = x ** 2
# Create the line plot
plt.plot(x, y)
# Label the x-axis and y-axis
plt.xlabel('X')
plt.ylabel('Y')
# Add a title
plt.title('Basic Line Plot')
# Show the plot
plt.show()
 

#Exercise 2:
import matplotlib.pyplot as plt
import numpy as np
# Define the range of x values
x = np.linspace(-10, 10, 100)  # Creating 100 points between -10 and 10
# Calculate y values for y = x and y = x^2
y1 = x
y2 = x ** 2
# Create the multi-line plot with different colors and styles
plt.plot(x, y1, label='y = x', color='blue', linestyle='-', marker='o')
plt.plot(x, y2, label='y = x^2', color='red', linestyle='--', marker='x')
# Add a legend
plt.legend()
# Label the x-axis and y-axis
plt.xlabel('X')
plt.ylabel('Y')
# Add a title
plt.title('Multi-Line Plot')
# Show the plot
plt.show() 
 

#Exercise 3:
import matplotlib.pyplot as plt
# Student names and their math scores
students = ["Alice", "Bob", "Charlie", "Diana", "Ethan"]
math_scores = [78, 82, 89, 94, 85]
# Create a bar chart
plt.bar(students, math_scores, color='skyblue')
# Label the x-axis and y-axis
plt.xlabel("Students")
plt.ylabel("Math Scores")
# Add a title
plt.title("Math Performance")
# Show the plot
plt.show() 
 

#Exercise 4:
import matplotlib.pyplot as plt
# Student names
students = ["Alice", "Bob", "Charlie", "Diana", "Ethan"]
# Scores
math_scores = [78, 82, 89, 94, 85]
science_scores = [80, 85, 78, 90, 88]
# Create the scatter plot
plt.scatter(math_scores, science_scores, color='green')
# Label the axes
plt.xlabel("Math Scores")
plt.ylabel("Science Scores")
# Add a title
plt.title("Math vs. Science Scores")
# Add a legend
plt.legend(students)
# Show the plot
plt.show() 
 

#Exercise 5:
import matplotlib.pyplot as plt
import numpy as np
# Define the range of x values
x = np.linspace(-2 * np.pi, 2 * np.pi, 100)
# Calculate y values for y = sin(x)
y = np.sin(x)
# Create the plot with customized appearance
plt.plot(x, y, color='green', linestyle='--', marker='D')
# Add grid lines
plt.grid(True)
# Label the x-axis and y-axis
plt.xlabel('X')
plt.ylabel('Y')
# Add a title
plt.title('Sine Function')
# Show the plot
plt.show() 
 

#Exercise 6:
import matplotlib.pyplot as plt
# Exam scores
scores = [72, 88, 95, 70, 83, 85, 94, 100, 78, 84]
# Create the histogram
plt.hist(scores, bins=5, edgecolor='black')
# Label the x-axis and y-axis
plt.xlabel('Scores')
plt.ylabel('Frequency')
# Add a title
plt.title('Distribution of Exam Scores')
# Show the plot
plt.show() 
 

#Exercise 7:
import matplotlib.pyplot as plt
# Participation rates
labels = ['Excellent', 'Good', 'Average', 'Below Average']
sizes = [40, 30, 20, 10]
# Create the pie chart
plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=140)
# Add a title
plt.title('Classroom Participation')
# Ensure that pie is drawn as a circle
plt.axis('equal')
# Show the plot
plt.show() 
 
