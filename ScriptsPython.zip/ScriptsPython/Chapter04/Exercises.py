# Exercise 1 :
import math

a = 5
b = 12
c = math.sqrt(a**2 + b**2)

print("The hypotenuse of the triangle is:", c)
 
# Exercise 2 :
import math

def compute_area_of_circle(radius):
    return math.pi * radius * radius

# Test
radius = 5
area = compute_area_of_circle(radius)
print(f"The area of the circle with radius {radius} units is {area:.2f} square units.") 
 
# Exercise 3 :
import datetime

def days_left_in_year():
    today = datetime.date.today()
    end_of_year = datetime.date(today.year, 12, 31)
    return (end_of_year - today).days

# Test
days_remaining = days_left_in_year()
print(f"There are {days_remaining} days left in this year.")

 
# Exercise 4 :
import datetime

today = datetime.date.today()
# Example:  January 1
next_birthday = datetime.date(today.year, month=1, day=1)   
if next_birthday < today:
    next_birthday = next_birthday.replace(year=today.year + 1)
days_until_birthday = (next_birthday - today).days
print("Days until next birthday:", days_until_birthday) 
 
# Exercise 5 :
import datetime

today = datetime.datetime.now()
future_date = today + datetime.timedelta(days=100)
print("Date in 100 days:", future_date) 
 
# Exercise 6 :
from fractions import Fraction

f1 = Fraction(1, 3)
f2 = Fraction(2, 5)

add_result = f1 + f2
subtract_result = f1 - f2
multiply_result = f1 * f2
divide_result = f1 / f2

print("Add:", add_result)
print("Subtract:", subtract_result)
print("Multiply:", multiply_result)
print("Divide:", divide_result) 
 
# Exercise 7 :
import random

def roll_die(sides):
    return random.randint(1, sides)

# Simulating the rolls
six_sided_roll = roll_die(6)
twenty_sided_roll = roll_die(20)

print(f"Roll of a six-sided die: {six_sided_roll}")
print(f"Roll of a twenty-sided die: {twenty_sided_roll}")

 
 
# Exercise 8 :
import pickle

address_book = {}

def save_contacts():
    with open("contacts.pkl", "wb") as f:
        pickle.dump(address_book, f)

def load_contacts():
    global address_book
    with open("contacts.pkl", "rb") as f:
        address_book = pickle.load(f)

def add_contact(name, phone, email):
    address_book[name] = {"phone": phone, "email": email}
    save_contacts()

def get_contact(name):
    return address_book.get(name)

# Example of use
add_contact("Alice", "123-456-7890", "alice@example.com")
print(get_contact("Alice"))

# This will load previously saved contacts
load_contacts()
 
 
# Exercise 9 :
import numpy as np

def create_chessboard(size=8):
    pattern = np.array([[0, 1], [1, 0]])
    return np.tile(pattern, (size//2, size//2))

chessboard = create_chessboard()
print(chessboard)
 
 
# Exercise 10 :
import matplotlib.pyplot as plt

# Sample data: grades for ten subjects
subjects = ["Math", "Science", "English", "History", "Art", "PE", "Music", "Computer Science", "Biology", "Physics"]
grades = [85, 90, 78, 88, 92, 75, 89, 95, 87, 82]

# Plotting the line chart
plt.figure(figsize=(10,6))
plt.plot(subjects, grades, marker='o', color='b', label='Grades')
plt.title('Student\'s Grades Throughout the Year')
plt.xlabel('Subjects')
plt.ylabel('Grades (%)')
plt.xticks(rotation=45)
plt.ylim(0, 100)  # Assuming grades are given as percentages
plt.grid(True, which='both', linestyle='--', linewidth=0.5)
plt.tight_layout()
plt.legend()
plt.show() 
 
# Exercise 11 :
import matplotlib.pyplot as plt
import numpy as np

# Coefficients
a, b, c = 1, 0, -4  # Example coefficients for y = x^2 - 4

# Generating values
x = np.linspace(-10, 10, 400)
y = a * x**2 + b * x + c

# Creating the plot
plt.figure()
plt.plot(x, y)
plt.title('Plot of the function y = x^2 - 4')
plt.xlabel('x')
plt.ylabel('y')
plt.grid(True)
plt.axhline(0, color='black',linewidth=0.5)
plt.axvline(0, color='black',linewidth=0.5)
plt.show() 
 
# Exercise 12 :
import numpy as np

# Generating a dataset
data = np.random.randint(1, 100, size=50)  # Random integers between 1 and 100

# Calculating statistics
mean = np.mean(data)
median = np.median(data)
std_dev = np.std(data)

print("Mean:", mean)
print("Median:", median)
print("Standard Deviation:", std_dev) 
 
# Exercise 13 :
from decimal import Decimal, getcontext

# Setting precision
getcontext().prec = 3

# Compound interest formula: A = P * (1 + r)**t
P = Decimal('1000.00')  # Principal amount
r = Decimal('0.05')     # Annual interest rate
t = Decimal('3')        # Time in years

# Calculate compound interest
A = P * (1 + r) ** t

print("Total amount after 3 years with compound interest:", A) 
 
# Exercise 14 :
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression
from sklearn.datasets import make_blobs

# Step 1: Generate synthetic data
# Create a dataset with 100 samples, divided into 2 clusters (or classes)
X, y = make_blobs(n_samples=100, centers=2, random_state=6)

# Step 2: Create and train the classifier
# Initialize the Logistic Regression classifier
model = LogisticRegression()
# Fit (train) the model with the generated data
model.fit(X, y)

# Step 3: Create a grid to evaluate the model
# Set the minimum and maximum values for the grid, padded by 1 unit each side
x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
# Create a meshgrid for the x and y axis
xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.1),
                     np.arange(y_min, y_max, 0.1))

# Step 4: Predict class for each point in the grid
# Predict the output for each point on the meshgrid
Z = model.predict(np.c_[xx.ravel(), yy.ravel()])
# Reshape the output to match the shape of xx
Z = Z.reshape(xx.shape)

# Step 5: Visualize the decision boundaries
# Use contour plot to show the decision boundaries
plt.contourf(xx, yy, Z, alpha=0.4)
# Scatter plot of the actual data points
plt.scatter(X[:, 0], X[:, 1], c=y, s=20, edgecolor='k')
plt.title("Logistic Regression Decision Boundaries")
plt.xlabel('Feature 1')
plt.ylabel('Feature 2')
plt.show() 
 
# Exercise 15 :
# Step 1: Import necessary libraries
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

# Step 2: Load the California housing dataset
california_housing = fetch_california_housing()

# Step 3: Explore the dataset
# This dataset contains features such as median income, housing median age, average rooms, etc.
# We'll use these features to predict the median house value.
print("Feature Names:", california_housing.feature_names)
print("Target Name:", california_housing.target_names)

# Step 4: Split the dataset into training and testing sets
# We'll use 75% of the data for training and 25% for testing
X_train, X_test, y_train, y_test = train_test_split(california_housing.data, california_housing.target, test_size=0.25, random_state=42)

# Step 5: Train the linear regression model
# Create a linear regression object
model = LinearRegression()
# Fit the model to the training data
model.fit(X_train, y_train)

# Step 6: Evaluate the model
# Predict the house prices on the test set
predictions = model.predict(X_test)
# Calculate the Mean Squared Error (MSE) to evaluate the model's performance
mse = mean_squared_error(y_test, predictions)
print("Mean Squared Error:", mse)

# Step 7: Interpret the results
# The lower the MSE, the better the model's performance. 
# A low MSE indicates that the model's predictions are close to the actual house prices. 
 
# Exercise 16 :
print('Exercise 16')
import requests
from bs4 import BeautifulSoup

# Step 1: Set the URL of the website
url = 'http://books.toscrape.com/'

# Step 2: Send a request to the website
response = requests.get(url)

# Explicitly set the response encoding to UTF-8 if not set correctly
response.encoding = 'utf-8'

# Step 3: Parse the HTML content of the page
soup = BeautifulSoup(response.text, 'html.parser')

# Step 4: Extract data about books
books = soup.find_all('article', class_='product_pod')

print("Available Books:")
for book in books:
    title = book.find('h3').find('a')['title']
    price = book.find('p', class_='price_color').text
    stock = book.find('p', class_='instock availability').text.strip()
    print(f"Title: {title}, Price: {price}, Availability: {stock}")
 
# Exercise 17 :
import requests
from bs4 import BeautifulSoup

# Step 1: Define the URL for the HTTP request
url = 'https://httpbin.org/user-agent'

# Step 2: Send a GET request to the URL
response = requests.get(url)

# Step 3: Parse the JSON response
# The response from HTTPBin for /user-agent endpoint is JSON, containing the user-agent used in the request
user_agent_info = response.json()

# Step 4: Print the user-agent information
print("User-Agent Information:", user_agent_info['user-agent']) 
 
# Exercise 18 :
import sqlite3

# Connect to SQLite database (or create if it doesn't exist)
conn = sqlite3.connect('school.db')
c = conn.cursor()

# Create a new table named Students
c.execute('''
CREATE TABLE Students (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    grade INTEGER NOT NULL
)
''')

# Insert sample data into the table
students_data = [
    (1, 'Alice', 85),
    (2, 'Bob', 90),
    (3, 'Charlie', 78)
]
c.executemany('INSERT INTO Students VALUES (?, ?, ?)', students_data)
conn.commit()

# Close the connection to the database
conn.close() 
 
# Exercise 19 :

import sqlite3

# Connect to the SQLite database
conn = sqlite3.connect('school.db')
c = conn.cursor()

# Query to find students with grade above 80
c.execute('SELECT name FROM Students WHERE grade > 80')

# Fetch all matching records and print them
print("Students with grade above 80:")
for student in c.fetchall():
    print(student[0])

# Close the connection
conn.close() 
 
# Exercise 20 :
import sqlite3

# Connect to the database
conn = sqlite3.connect('school.db')
c = conn.cursor()

# Update a student's grade
c.execute('UPDATE Students SET grade = 95 WHERE name = "Alice"')

# Delete a student's record
c.execute('DELETE FROM Students WHERE name = "Bob"')

# Commit changes and close the connection
conn.commit()
conn.close()

print("Updated Alice's grade to 95 and deleted Bob's record.") 
 
# Exercise 21 :
import pygame
import random
import sys

# Initialize Pygame
pygame.init()

# Set up the display
screen_width, screen_height = 800, 600
screen = pygame.display.set_mode((screen_width, screen_height))

# Colors
white = (255, 255, 255)
red = (255, 0, 0)

# Game clock
clock = pygame.time.Clock()

# Basket settings
basket_width, basket_height = 100, 20
basket_x = (screen_width - basket_width) / 2
basket_y = screen_height - basket_height - 10
basket_speed = 10

# Apple settings
apple_width, apple_height = 20, 20
apple_x = random.randint(0, screen_width - apple_width)
apple_y = 0
apple_fall_speed = 5

# Game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Key movement
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] and basket_x > 0:
        basket_x -= basket_speed
    if keys[pygame.K_RIGHT] and basket_x < screen_width - basket_width:
        basket_x += basket_speed

    # Apple falling logic
    apple_y += apple_fall_speed

    # Check collision
    if apple_y + apple_height >= basket_y:  # Check if apple has reached the basket height
        if apple_x >= basket_x and apple_x + apple_width <= basket_x + basket_width:
            # Apple is within the basket, reset apple
            apple_y = 0
            apple_x = random.randint(0, screen_width - apple_width)
        elif apple_y + apple_height >= screen_height:
            # Apple has reached the bottom of the screen, reset apple
            apple_y = 0
            apple_x = random.randint(0, screen_width - apple_width)

    # Drawing
    screen.fill(white)
    pygame.draw.rect(screen, red, (apple_x, apple_y, apple_width, apple_height))
    pygame.draw.rect(screen, red, (basket_x, basket_y, basket_width, basket_height))
    
    pygame.display.flip()
    clock.tick(30)

 
