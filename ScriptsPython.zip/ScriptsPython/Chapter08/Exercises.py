#Exercise 1:
class Book:
    def __init__(self, title, author, year_published):
        self.title = title
        self.author = author
        self.year_published = year_published 
my_book = Book("The Great Gatsby", "F. Scott Fitzgerald", 1925) 
print(f"Title: {my_book.title}")
print(f"Author: {my_book.author}")
print(f"Year Published: {my_book.year_published}")
#Exercise 2:
import datetime

class Book:
    def __init__(self, title, author, year_published):
        self.title = title
        self.author = author
        self.year_published = year_published

    def age(self):
        current_year = datetime.datetime.now().year
        return current_year - self.year_published 
my_book = Book("The Great Gatsby", "F. Scott Fitzgerald", 1925)
print(f"Age of the book '{my_book.title}': {my_book.age()} years") 

#Exercise 3:
import math

class Circle:
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return math.pi * (self.radius**2)

    def perimeter(self):
        return 2 * math.pi * self.radius 
circle_instance = Circle(5)
print(f"Area of the circle with radius 5: {circle_instance.area():.2f}")
print(f"Perimeter of the circle with radius 5: {circle_instance.perimeter():.2f}") 

#Exercise 4:
class Student:
    def __init__(self, name, age, grade):
        self.name = name
        self.age = age
        self.grade = grade

    def increment_age(self):
        self.age += 1

    def update_grade(self, new_grade):
        self.grade = new_grade

    def __str__(self):
        return f"Name: {self.name}, Age: {self.age}, Grade: {self.grade}"

# Testing the class
student1 = Student("Alice", 15, "10th Grade")
print(student1)  # Expected: Name: Alice, Age: 15, Grade: 10th Grade

student1.increment_age()
print(student1)  # Expected: Name: Alice, Age: 16, Grade: 10th Grade

student1.update_grade("11th Grade")
print(student1)  # Expected: Name: Alice, Age: 16, Grade: 11th Grade 
 

#Exercise 5:
class Student:
    def __init__(self, name, age, grade):
        self.name = name
        self.age = age
        self.grade = grade

class CollegeStudent(Student):
    def __init__(self, name, age, grade, major):
        super().__init__(name, age, grade)
        self.major = major 
 
student_instance = CollegeStudent("Alice", 20, "Sophomore", "Computer Science")
print(f"{student_instance.name} is a {student_instance.age} year old {student_instance.grade} majoring in {student_instance.major}.")
#Exercise 6:
 
class Student:
    def __init__(self, name, age, grade):
        self.name = name
        self.age = age
        self.grade = grade

    def update_grade(self, new_grade):
        self.grade = new_grade

class CollegeStudent(Student):
    VALID_GRADES = ["Freshman", "Sophomore", "Junior", "Senior"]
    
    def __init__(self, name, age, grade, major):
        super().__init__(name, age, grade)
        self.major = major

    # Overriding the update_grade method
    def update_grade(self, new_grade):
        if new_grade in self.VALID_GRADES:
            self.grade = new_grade
            print(f"Grade updated to {new_grade}.")
        else:
            print(f"'{new_grade}' is not a valid college grade!") 

alice = CollegeStudent("Alice", 20, "Sophomore", "Computer Science")
alice.update_grade("Masters")  # This will print an error since 'Masters' is not a valid grade.
alice.update_grade("Junior")   # This will successfully update Alice's grade. 

#Exercise 7:
class Vehicle:
    def __init__(self, number_of_wheels, color):
        self.number_of_wheels = number_of_wheels
        self.color = color

    def display_info(self):
        print(f"This is a {self.color} vehicle with {self.number_of_wheels} wheels.")

class Car(Vehicle):
    def __init__(self, color):
        super().__init__(4, color)

    def display_info(self):
        print(f"This is a {self.color} car with {self.number_of_wheels} wheels.")

class Bicycle(Vehicle):
    def __init__(self, color):
        super().__init__(2, color)

    def display_info(self):
        print(f"This is a {self.color} bicycle with {self.number_of_wheels} wheels.")
sedan = Car("red")
sedan.display_info()  # This will print: This is a red car with 4 wheels.

mountain_bike = Bicycle("blue")
mountain_bike.display_info()  # This will print: This is a blue bicycle with 2 wheels. 

#Exercise 8:
class Vehicle:
    def __init__(self, number_of_wheels, color):
        self.number_of_wheels = number_of_wheels
        self.color = color

    def sound(self):
        pass

    def display_info(self):
        print(f"This is a {self.color} vehicle with {self.number_of_wheels} wheels.")

class Car(Vehicle):
    def __init__(self, color):
        super().__init__(4, color)

    def sound(self):
        return "Vroom"

    def display_info(self):
        print(f"This is a {self.color} car with {self.number_of_wheels} wheels. It sounds: {self.sound()}")

class Bicycle(Vehicle):
    def __init__(self, color):
        super().__init__(2, color)

    def sound(self):
        return "Ring ring"

    def display_info(self):
        print(f"This is a {self.color} bicycle with {self.number_of_wheels} wheels. It sounds: {self.sound()}")  

sedan = Car("red")
sedan.display_info()  # Prints:  This is a red car with 4 wheels. It sounds: Vroom

mountain_bike = Bicycle("blue")
mountain_bike.display_info()  # Prints:  This is a blue bicycle with 2 wheels. It sounds: Ring ring
#Exercise 9:
class Student:
    def __init__(self, name, grade):
        self.__name = name
        self.__grade = grade

    # Getter for name
    def get_name(self):
        return self.__name

    # Setter for name
    def set_name(self, name):
        self.__name = name

    # Getter for grade
    def get_grade(self):
        return self.__grade

    # Setter for grade
    def set_grade(self, grade):
        self.__grade = grade

# Testing the encapsulated Student class
s1 = Student("Alice", "A")
print(s1.get_name())  # This will print: Alice
print(s1.get_grade()) # This will print: A

s1.set_name("Bob")
s1.set_grade("B")
print(s1.get_name())  # This will print: Bob
print(s1.get_grade()) # This will print: B 
 

#Exercise 10:
class MusicAlbum:
    def __init__(self, artist, title):
        self.__artist = artist
        self.__title = title
        self.__songs = []

    # Getter for artist
    def get_artist(self):
        return self.__artist

    # Getter for title
    def get_title(self):
        return self.__title

    # Getter for songs
    def get_songs(self):
        return self.__songs

    # Add a song to the album
    def add_song(self, song):
        self.__songs.append(song)

    # Remove a song from the album
    def remove_song(self, song):
        if song in self.__songs:
            self.__songs.remove(song)

# Testing the MusicAlbum class
album = MusicAlbum("The Beatles", "Abbey Road")
album.add_song("Come Together")
album.add_song("Something")
print(album.get_songs())  # ['Come Together', 'Something']

album.remove_song("Something")
print(album.get_songs())  # ['Come Together'] 
 

#Exercise 11:
from abc import ABC, abstractmethod

class Shape(ABC):
    # Abstract method for area
    @abstractmethod
    def area(self):
        pass

    # Abstract method for perimeter
    @abstractmethod
    def perimeter(self):
        pass

class Triangle(Shape):
    def __init__(self, base, height, side1, side2, side3):
        self.base = base
        self.height = height
        self.side1 = side1
        self.side2 = side2
        self.side3 = side3

    def area(self):
        return 0.5 * self.base * self.height

    def perimeter(self):
        return self.side1 + self.side2 + self.side3

class Rectangle(Shape):
    def __init__(self, width, height):
        self.width = width
        self.height = height

    def area(self):
        return self.width * self.height

    def perimeter(self):
        return 2 * (self.width + self.height)

# Testing the classes
tri = Triangle(10, 5, 3, 4, 5)
print(tri.area())       # 25.0
print(tri.perimeter())  # 12

rect = Rectangle(4, 6)
print(rect.area())      # 24
print(rect.perimeter()) # 20 
 

#Exercise 12:
class MusicAlbum:
    def __init__(self, artist, title):
        self.__artist = artist
        self.__title = title
        self.__songs = []

    def add_song(self, song):
        self.__songs.append(song)

    def remove_song(self, song):
        if song in self.__songs:
            self.__songs.remove(song)

    def play_album(self):
        for song in self.__songs:
            print(f"Playing: {song} by {self.__artist}")

class Playlist:
    def __init__(self, name):
        self.__name = name
        self.__albums = []

    def add_album(self, album):
        self.__albums.append(album)

    def remove_album(self, album):
        if album in self.__albums:
            self.__albums.remove(album)

    def play_playlist(self):
        for album in self.__albums:
            album.play_album()

# Testing the classes
album1 = MusicAlbum("Queen", "Bohemian Rhapsody")
album1.add_song("Song A")
album1.add_song("Song B")

album2 = MusicAlbum("Beatles", "Yellow Submarine")
album2.add_song("Song X")
album2.add_song("Song Y")

playlist = Playlist("My Favorite Songs")
playlist.add_album(album1)
playlist.add_album(album2)
playlist.play_playlist() 
 

#Exercise 13:
class BankAccount:
    def __init__(self, account_number, initial_balance=0):
        self.__account_number = account_number
        self.__balance = initial_balance

    def deposit(self, amount):
        if amount > 0:
            self.__balance += amount
            print(f"Deposited ${amount}. New balance: ${self.__balance}")
        else:
            print("Invalid deposit amount!")

    def withdraw(self, amount):
        if amount > 0 and amount <= self.__balance:
            self.__balance -= amount
            print(f"Withdrew ${amount}. New balance: ${self.__balance}")
        elif amount > self.__balance:
            print("Insufficient funds!")
        else:
            print("Invalid withdrawal amount!")

    def check_balance(self):
        print(f"Account Balance for {self.__account_number}: ${self.__balance}")

# Testing the class
account = BankAccount("12345", 100)
account.check_balance()
account.deposit(50)
account.withdraw(20)
account.check_balance() 
 

#Exercise 14:
class BankAccount:
    def __init__(self, account_number, initial_balance=0):
        self.__account_number = account_number
        self.__balance = initial_balance

    def deposit(self, amount):
        if amount > 0:
            self.__balance += amount
            print(f"Deposited ${amount}. New balance: ${self.__balance}")
        else:
            print("Invalid deposit amount!")

    def withdraw(self, amount):
        if amount > 0 and amount <= self.__balance:
            self.__balance -= amount
            print(f"Withdrew ${amount}. New balance: ${self.__balance}")
        elif amount > self.__balance:
            print("Insufficient funds!")
        else:
            print("Invalid withdrawal amount!")

    def check_balance(self):
        return self.__balance

class SavingsAccount(BankAccount):
    def __init__(self, account_number, initial_balance=0, interest_rate=0.01):
        super().__init__(account_number, initial_balance)
        self.__interest_rate = interest_rate

    def apply_interest(self):
        interest = super().check_balance() * self.__interest_rate
        self.deposit(interest)
        print(f"Applied interest of ${interest}. New balance: ${super().check_balance()}")

# Testing the subclass
savings = SavingsAccount("67890", 1000)
savings.apply_interest()
savings.withdraw(100) 
 

#Exercise 15:
class Student:
    def __init__(self, student_id, name, grade):
        self.__student_id = student_id
        self.__name = name
        self.__grade = grade

    def get_id(self):
        return self.__student_id

    def get_name(self):
        return self.__name

    def __str__(self):
        return f"ID: {self.__student_id}, Name: {self.__name}, Grade: {self.__grade}"

class StudentDatabase:
    def __init__(self):
        self.__students = {}  # Dictionary to store students

    def add_student(self, student):
        if student.get_id() not in self.__students:
            self.__students[student.get_id()] = student
            print(f"Added {student.get_name()} to the database.")
        else:
            print(f"Student with ID {student.get_id()} already exists.")

    def remove_student(self, student_id):
        if student_id in self.__students:
            print(f"Removed {self.__students[student_id].get_name()} from the database.")
            del self.__students[student_id]
        else:
            print(f"Student with ID {student_id} not found.")

    def search_student(self, student_id):
        return self.__students.get(student_id, "Student not found.")

# Testing the StudentDatabase class
db = StudentDatabase()
alice = Student("001", "Alice", "A")
bob = Student("002", "Bob", "B")

db.add_student(alice)
db.add_student(bob)
print(db.search_student("001"))
db.remove_student("002")
print(db.search_student("002")) 
 

#Exercise 16:
class Book:
    def __init__(self, isbn, title, author, year_published):
        self.__isbn = isbn
        self.__title = title
        self.__author = author
        self.__year_published = year_published

    def get_isbn(self):
        return self.__isbn

    def __str__(self):
        return f"ISBN: {self.__isbn}, Title: {self.__title}, Author: {self.__author}, Year: {self.__year_published}"

class Library:
    def __init__(self):
        self.__books = {}  # Dictionary to store books using ISBN as key

    def add_book(self, book):
        if book.get_isbn() not in self.__books:
            self.__books[book.get_isbn()] = book
            print(f"Added '{book.__str__()}' to the library.")
        else:
            print(f"Book with ISBN {book.get_isbn()} already exists.")

    def remove_book(self, isbn):
        if isbn in self.__books:
            print(f"Removed '{self.__books[isbn].__str__()}' from the library.")
            del self.__books[isbn]
        else:
            print(f"Book with ISBN {isbn} not found.")

    def find_book(self, isbn):
        return self.__books.get(isbn, "Book not found.")

# Testing the Library class
lib = Library()
hobbit = Book("978-0261102354", "The Hobbit", "J.R.R. Tolkien", "1937")
potter = Book("978-0747532743", "Harry Potter and the Philosopher's Stone", "J.K. Rowling", "1997")

lib.add_book(hobbit)
lib.add_book(potter)
print(lib.find_book("978-0261102354"))
lib.remove_book("978-0747532743")
print(lib.find_book("978-0747532743")) 
 

#Exercise 17:
class Pets:
    def __init__(self, name, species):
        self.__name = name
        self.__species = species

    def __str__(self):
        return f"{self.__name} ({self.__species})"

class PetOwner:
    def __init__(self, owner_name):
        self.__owner_name = owner_name
        self.__pets = []  # List to store instances of Pets

    def add_pet(self, pet):
        self.__pets.append(pet)
        print(f"{self.__owner_name} now has {pet.__str__()} as a pet!")

    def show_pets(self):
        print(f"{self.__owner_name}'s pets are:")
        for pet in self.__pets:
            print(pet.__str__())

# Testing the PetOwner class
alice = PetOwner("Alice")
whiskers = Pets("Whiskers", "Cat")
buddy = Pets("Buddy", "Dog")

alice.add_pet(whiskers)
alice.add_pet(buddy)
alice.show_pets() 
 

#Exercise 18:
from abc import ABC, abstractmethod

class Appliance(ABC):

    @abstractmethod
    def turn_on(self):
        pass

    @abstractmethod
    def turn_off(self):
        pass

class WashingMachine(Appliance):

    def turn_on(self):
        print("Washing Machine is now ON.")

    def turn_off(self):
        print("Washing Machine is now OFF.")

class Oven(Appliance):

    def turn_on(self):
        print("Oven is now ON.")

    def turn_off(self):
        print("Oven is now OFF.")

# Testing the subclasses
washer = WashingMachine()
washer.turn_on()
washer.turn_off()

oven = Oven()
oven.turn_on()
oven.turn_off() 
 

#Exercise 19:
class Item:
    def __init__(self, name, price):
        self.name = name
        self.price = price

    def __str__(self):
        return f"{self.name} (${self.price:.2f})"

class Book(Item):
    def __init__(self, name, price, author):
        super().__init__(name, price)
        self.author = author

    def __str__(self):
        return f"{self.name} by {self.author} (${self.price:.2f})"

class Electronic(Item):
    def __init__(self, name, price, brand):
        super().__init__(name, price)
        self.brand = brand

    def __str__(self):
        return f"{self.brand} {self.name} (${self.price:.2f})"

class OnlineStore:
    def __init__(self):
        self.cart = []

    def add_to_cart(self, item):
        self.cart.append(item)

    def remove_from_cart(self, item_name):
        for item in self.cart:
            if item.name == item_name:
                self.cart.remove(item)
                break

    def checkout(self):
        total = sum(item.price for item in self.cart)
        print("Checkout Items:")
        for item in self.cart:
            print(item)
        print(f"Total: ${total:.2f}")

# Testing the classes
book = Book("The Great Gatsby", 10.99, "F. Scott Fitzgerald")
phone = Electronic("iPhone", 999.99, "Apple")

store = OnlineStore()
store.add_to_cart(book)
store.add_to_cart(phone)
store.checkout() 
 

#Exercise 20:
class Game:
    def __init__(self, name, developer):
        self.name = name
        self.developer = developer
        self.ratings = []

    def add_rating(self, rating):
        if 1 <= rating <= 5:  # Assuming a rating system of 1 to 5 stars.
            self.ratings.append(rating)
        else:
            print("Invalid rating! Please rate between 1 and 5.")

    def average_rating(self):
        if not self.ratings:
            return "No ratings yet!"
        avg = sum(self.ratings) / len(self.ratings)
        return f"Average rating: {avg:.2f} stars"

    def __str__(self):
        return f"{self.name} by {self.developer}. {self.average_rating()}"

# Testing the class
game1 = Game("Minecraft", "Mojang")
game1.add_rating(4)
game1.add_rating(5)
game1.add_rating(5)
game1.add_rating(3)

print(game1)   
