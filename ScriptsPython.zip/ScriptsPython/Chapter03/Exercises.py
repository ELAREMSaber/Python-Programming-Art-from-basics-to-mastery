# Exercise 1 :
def hello_world():
    print("Hello, World!")

hello_world()  
 
# Exercise 2 :
def add_numbers(a, b):
    return a + b

result = add_numbers(5, 3)
print(result)    
 
# Exercise 3 :
def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n-1)

result = factorial(5)
print(result)   
 
# Exercise 4 :
multiply = lambda x, y: x * y

result = multiply(7, 8)
print(result)   
 
# Exercise 5 :
def square(n):
    return n * n

def square_list(numbers):
    return list(map(square, numbers))

# Example usage:
numbers = [1, 2, 3, 4, 5]
squared_numbers = square_list(numbers)
print(squared_numbers)


 
# Exercise 6 :
def is_odd(n):
    return n % 2 != 0

def filter_odd(numbers):
    return list(filter(is_odd, numbers))

# Example usage:
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
odd_numbers = filter_odd(numbers)
print(odd_numbers)    
 
# Exercise 7 :
def add(a, b):
    """
    Add two numbers and return their sum.

    Parameters:
    - a: First number.
    - b: Second number.

    Returns:
    Sum of a and b.
    """
    return a + b

# Access and print the docstring
print(add.__doc__) 
 
# Exercise 8 :
def display_args(*args, **kwargs):
    """
    Display an arbitrary number of positional and keyword arguments.

    Parameters:
    *args: Positional arguments.
    **kwargs: Keyword arguments.
    """
    # Print positional arguments
    for arg in args:
        print(arg)

    # Print keyword arguments
    for key, value in kwargs.items():
        print(f"{key} = {value}")

# Test the function
display_args(1, 2, 3, a=4, b=5, c=6)
 
# Exercise 9 :
# Global variable
global_var = "I am a global variable"

def demonstrate_variables():
    # Local variable
    local_var = "I am a local variable"
    
    print(global_var)  # Accessible inside the function
    print(local_var)   # Accessible only inside the function

demonstrate_variables()

try:
    print(local_var)   # This will raise an error
except NameError:
    print("local_var is not accessible outside the function.") 
 
# Exercise 10 :
def fibonacci(n):
    if n <= 1:
        return n
    else:
        return fibonacci(n-1) + fibonacci(n-2)

# Example: To find the 6th number in the Fibonacci sequence
result = fibonacci(6)
print(f"The 6th number in the Fibonacci sequence is: {result}") 
 
# Exercise 11 :
from functools import reduce

def product_of_numbers(lst):
    return reduce(lambda x, y: x * y, lst)

numbers = [1, 2, 3, 4, 5]
result = product_of_numbers(numbers)
print(result)   
 
# Exercise 12 :
def incrementer(n):
    def add(x):
        return x + n
    return add

# Create an incrementer function that adds 5
add_five = incrementer(5)

print(add_five(10))  # Output: 15
print(add_five(25))  # Output: 30 
 
# Exercise 13 :
# math_module.py

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    if b != 0:
        return a / b
    else:
        return "Undefined (Division by zero)" 

# main.py

## uncomment : from math_module import add

result = add(5, 3)
print(result)

# Exercise 14 :
def is_prime(n):
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0 or n % 3 == 0:
        return False
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    return True

# Test the function
number = 17
if is_prime(number):
    print(f"{number} is a prime number.")
else:
    print(f"{number} is not a prime number.") 
 
# Exercise 15 :
def gcd(a, b):
    if b == 0:
        return a
    else:
        return gcd(b, a % b)

# Usage example:
result = gcd(56, 98)
print(result)    
 
# Exercise 16 :
def letter_count(s):
    # Initializing an empty dictionary
    count_dict = {}
    
    # Iterating over the string
    for char in s:
        # Ignoring spaces and non-letter characters
        if char.isalpha():
            # Converting to lowercase for case-insensitivity
            char = char.lower()
            
            # Incrementing the count or setting it to 1 if not in dictionary
            count_dict[char] = count_dict.get(char, 0) + 1
            
    return count_dict

# Usage example:
string_input = "Hello, World!"
result = letter_count(string_input)
print(result) 
 
# Exercise 17 :
import math

def find_lcm(num1, num2):
    gcd = math.gcd(num1, num2)
    lcm = abs(num1 * num2) // gcd
    return lcm

# Example usage:
print(find_lcm(12, 18))  
print(find_lcm(5, 7))    
print(find_lcm(21, 6))   
 
# Exercise 18 :
def add(x, y):
    return x + y

def multiply(x, y):
    return x * y

def operate(func, x, y):
    return func(x, y)

# Example usage:
print(operate(add, 5, 3))   
print(operate(multiply, 4, 6))  
 
# Exercise 19 :
def multiplication_table(list1, list2):
    # Initialize an empty list to store the rows of the multiplication table
    result_table = []

    # Iterate over each element in list1
    for x in list1:
        # For each element in list1, initialize a new row in the table
        row = []
        # Iterate over each element in list2
        for y in list2:
            # Multiply the elements from list1 and list2
            product = x * y
            # Append the product to the current row
            row.append(product)
        # After finishing with one element from list1, add the completed row to the table
        result_table.append(row)

    # Return the complete multiplication table
    return result_table

# Example usage:
list1 = [1, 3, 5, 7]
list2 = [2, 4, 6]
table = multiplication_table(list1, list2)
# This will print a list of lists where each sublist is a row of the multiplication table
print(table) 
 
