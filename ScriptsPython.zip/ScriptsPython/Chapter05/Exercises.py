# Exercise 1 
# Create an empty list to store the even numbers
even_numbers = []

# Iterate ten times to get the first ten even numbers
for i in range(1, 11):
    even_numbers.append(i * 2)

# Print the list of even numbers
print(even_numbers)

# Exercise 2 
# Create a tuple containing five favorite movies
favorite_movies = ("The Shawshank Redemption", "The Godfather", "Pulp Fiction", "The Dark Knight", "Forrest Gump")

# Access and print the third movie
print(favorite_movies[2]) 

# Exercise 3 
# Initialize a set with five fruits
fruits = {"apple", "banana", "cherry", "date", "elderberry"}

# Add another fruit to the set
fruits.add("fig")

# Remove a fruit from the set
fruits.remove("apple")

print(fruits) 

# Exercise 4 
# Initialize a dictionary to represent a student
student = {
    "name": "John Doe",
    "age": 16,
    "grade": 10,
    "school": "Springfield High"
}

print(student) 

# Exercise 5 
# Using list comprehension to generate squares of numbers from 1 to 10
squares = [num**2 for num in range(1, 11)]

print(squares) 

# Exercise 6 
# Creating a nested dictionary for three students
students = {
    "Student1": {"name": "Alice", "age": 16, "grade": "10th"},
    "Student2": {"name": "Bob", "age": 17, "grade": "11th"},
    "Student3": {"name": "Charlie", "age": 18, "grade": "12th"}
}

# Printing the students' details
for student_key, details in students.items():
    print(student_key + ":")
    for key, value in details.items():
        print(f"{key}: {value}")
    print("\n") 

# Exercise 7 
# Define a list of colors
colors = ["red", "green", "blue", "yellow", "purple"]

# Use enumerate to get both the index and value of each item
for index, color in enumerate(colors):
    print(f"Index: {index}, Color: {color}") 

# Exercise 8 
# Define a dictionary
original_dict = {'a': 1, 'b': 2, 'c': 3}

# Swap keys and values using dictionary comprehension
swapped_dict = {value: key for key, value in original_dict.items()}

# Print the swapped dictionary
print(swapped_dict) 

# Exercise 9 
# Define a set
fruits = {"apple", "banana", "cherry"}

# Use the add() method to add an element to the set
fruits.add("orange")
print("After adding orange:", fruits)

# Use the remove() method to remove an element from the set
fruits.remove("banana")
print("After removing banana:", fruits)

# Create another set
more_fruits = {"grape", "pineapple"}

# Use the union() method to get a new set that contains all items from both sets
all_fruits = fruits.union(more_fruits)
print("After union with more_fruits:", all_fruits) 

# Exercise 10 

import copy

# Original list containing inner lists
list_original = [[1, 2, 3], [4, 5, 6]]

# Make a shallow copy of the original list
list_shallow = copy.copy(list_original)

# Make a deep copy of the original list
list_deep = copy.deepcopy(list_original)

# Modify the first element of the first inner list
list_original[0][0] = 999

# Print the original and copied lists
print("Original List:", list_original)
print("Shallow Copy:", list_shallow)
print("Deep Copy:", list_deep) 

# Exercise 11 
# Sample dictionary
student = {
    "name": "John Doe",
    "age": 16,
    "grade": "11th",
    "school": "Springfield High"
}

# Iterate over the dictionary to print keys
for key in student:
    print(key) 

# Exercise 12 
# Sample dictionary
student = {
    "name": "John Doe",
    "age": 16,
    "grade": "11th",
    "school": "Springfield High"
}

# Iterate over the dictionary to print values
for value in student.values():
    print(value) 

# Exercise 13 
# Sample tuple
fruits_tuple = ("apple", "banana", "cherry", "date")

# Convert tuple to list
fruits_list = list(fruits_tuple)

# Modify an element in the list
fruits_list[2] = "blueberry"

# Convert the list back to a tuple if needed (optional)
modified_tuple = tuple(fruits_list)

# Print results
print("Original tuple:", fruits_tuple)
print("Modified list:", fruits_list)
print("Converted back to tuple:", modified_tuple) 

# Exercise 14 
# Sample dictionary
student = {
    "name": "John Doe",
    "grade": 10,
    "school": "High School"
}

# Using items() to get key-value pairs
print("Using items():")
for key, value in student.items():
    print(key, ":", value)

# Using keys() to get keys
print("\nUsing keys():")
for key in student.keys():
    print(key)

# Using values() to get values
print("\nUsing values():")
for value in student.values():
    print(value) 

# Exercise 15 
# Sample list of numbers
numbers = [1, 2, 3, 4, 5]

# Generator expression to get squares
squares = (n**2 for n in numbers)

# Iterating over the generator
for square in squares:
    print(square) 

# Exercise 16 
# Define two sample sets
set_a = {1, 2, 3, 4}
set_b = {3, 4, 5, 6}

# Union
union_result = set_a.union(set_b)  # Alternatively: set_a | set_b
print("Union:", union_result)

# Intersection
intersection_result = set_a.intersection(set_b)  # Alternatively: set_a & set_b
print("Intersection:", intersection_result)

# Difference
difference_result = set_a.difference(set_b)  # Alternatively: set_a - set_b
print("Difference (A - B):", difference_result) 

# Exercise 17 
# Define a dictionary to represent a book
book = {
    'title': 'The Great Gatsby',
    'author': 'F. Scott Fitzgerald',
    'publication_year': 1925,
    'genre': 'Novel'
}

# Print the book details
print("Title:", book['title'])
print("Author:", book['author'])
print("Publication Year:", book['publication_year'])
print("Genre:", book['genre']) 

# Exercise 18 
def frequency_counter(items_list):
    # Initialize an empty dictionary to store frequencies
    frequency_dict = {}
    
    # Iterate over the list
    for item in items_list:
        # If item is already in the dictionary, increment its count
        if item in frequency_dict:
            frequency_dict[item] += 1
        # Otherwise, add the item to the dictionary with a count of 1
        else:
            frequency_dict[item] = 1
    
    return frequency_dict

# Test the function
sample_list = ['apple', 'banana', 'apple', 'orange', 'banana', 'apple']
result = frequency_counter(sample_list)
print(result) 

# Exercise 19 
def flatten_list(nested_list):
    # Initialize an empty list to store flattened items
    flat_list = []
    
    # Iterate over the outer list
    for sublist in nested_list:
        # Iterate over each item in the sublist
        for item in sublist:
            flat_list.append(item)
    
    return flat_list

# Test the function
nested = [[1, 2, 3], [4, 5], [6, 7, 8, 9]]
flattened = flatten_list(nested)
print(flattened) 

# Exercise 20 
# Creating two frozensets
fs1 = frozenset([1, 2, 3, 4, 5])
fs2 = frozenset([4, 5, 6, 7, 8])

# Displaying the frozensets
print("Frozenset 1:", fs1)
print("Frozenset 2:", fs2)

# Performing basic set operations

# Union
union_fs = fs1.union(fs2)
print("Union of the two frozensets:", union_fs)

# Intersection
intersection_fs = fs1.intersection(fs2)
print("Intersection of the two frozensets:", intersection_fs)

# Difference
difference_fs = fs1.difference(fs2)
print("Difference (fs1 - fs2):", difference_fs) 

# Exercise 21 
def recursive_sum(lst):
    total = 0
    for item in lst:
        if isinstance(item, list):
            total += recursive_sum(item)
        else:
            total += item
    return total

flatten = lambda x: [a for b in x for a in (flatten(b) if isinstance(b, list) else [b])]

# Example usage:
nested_list = [1, 2, [3, 4, [5, 6]], 7]
print("Total Sum:", recursive_sum(nested_list))  # Expected output: 28
even_sum = sum(filter(lambda x: x % 2 == 0, flatten(nested_list)))
print("Sum of Even Numbers:", even_sum)  # Expected output: 12
 

# Exercise 22 
# statistics_module.py

def mean(numbers):
    """Calculate the mean of a list of numbers."""
    return sum(numbers) / len(numbers)

def median(numbers):
    """Calculate the median of a list of numbers."""
    sorted_nums = sorted(numbers)
    n = len(sorted_nums)
    mid = n // 2
    if n % 2 == 0:
        return (sorted_nums[mid - 1] + sorted_nums[mid]) / 2
    else:
        return sorted_nums[mid]

def mode(numbers):
    """Calculate the mode of a list of numbers."""
    frequency = {}
    for number in numbers:
        frequency[number] = frequency.get(number, 0) + 1
    max_freq = max(frequency.values())
    modes = [key for key, value in frequency.items() if value == max_freq]
    return modes

# Example usage in another script:
from statistics_module import mean, median, mode

data = [1, 2, 2, 3, 4, 4, 4, 5, 5]
print("Mean:", mean(data))
print("Median:", median(data))
print("Mode:", mode(data)) 

